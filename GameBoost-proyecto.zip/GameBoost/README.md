# GameBoost (Android)

Starter project for Android Studio. Package: `com.gameboost.app`.

## Included
- Native Android UI for GameBoost.
- Shizuku provider declaration and permission/service status check.
- Shortcuts to Android display, battery saver, and developer settings.
- No root requirement for the included features; no hidden system modifications.

## Build APK
1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync and install the Android SDK platform 35 if prompted.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is normally generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This environment did not have Android SDK or Gradle installed, so the APK has not been compiled or tested here.
- Shizuku must be installed and running on the phone. This starter only checks connection/permission; it does not yet run privileged shell commands or alter system settings through Shizuku.
- Performance depends on the phone, thermal state, OS and game. Avoid tools that promise universal FPS increases or disable thermal protection.
