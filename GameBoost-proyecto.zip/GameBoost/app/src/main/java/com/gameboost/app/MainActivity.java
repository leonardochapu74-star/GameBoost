package com.gameboost.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int SHIZUKU_PERMISSION_CODE = 2407;
    private TextView shizukuStatus;
    private LinearLayout root;
    private final int bg = Color.rgb(16, 19, 27);
    private final int panel = Color.rgb(29, 34, 46);
    private final int accent = Color.rgb(98, 230, 167);
    private final int white = Color.rgb(242, 245, 250);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        updateShizukuStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        root.setBackgroundColor(bg);
        scroll.setFillViewport(true);
        scroll.addView(root);

        TextView brand = text("GAMEBOOST", 13, accent, true);
        brand.setLetterSpacing(0.18f);
        root.addView(brand);
        TextView title = text("Tu móvil.\nModo gaming.", 32, white, true);
        LinearLayout.LayoutParams titleLp = params(-1, -2); titleLp.topMargin = dp(8); titleLp.bottomMargin = dp(8);
        root.addView(title, titleLp);
        root.addView(text("Herramientas seguras y ajustes reversibles para preparar el teléfono antes de jugar.", 15, Color.LTGRAY, false));

        LinearLayout card = card();
        TextView shTitle = text("Conexión Shizuku", 18, white, true);
        card.addView(shTitle);
        shizukuStatus = text("Comprobando servicio…", 14, Color.LTGRAY, false);
        LinearLayout.LayoutParams stLp = params(-1, -2); stLp.topMargin = dp(8);
        card.addView(shizukuStatus, stLp);
        Button connect = button("Comprobar / autorizar Shizuku");
        connect.setOnClickListener(v -> requestShizuku());
        LinearLayout.LayoutParams bLp = params(-1, dp(48)); bLp.topMargin = dp(14);
        card.addView(connect, bLp);
        root.addView(card, params(-1, -2));

        LinearLayout gameCard = card();
        gameCard.addView(text("Herramientas rápidas", 18, white, true));
        addAction(gameCard, "Abrir ajustes de pantalla", "Permite revisar la frecuencia de actualización disponible en tu dispositivo.", v -> startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        addAction(gameCard, "Ajustes de batería", "Revisa el modo de energía del fabricante. El ahorro de batería puede limitar el rendimiento.", v -> startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        addAction(gameCard, "Opciones de desarrollador", "Desde Android puedes modificar escalas de animación. Esto no aumenta por sí solo los FPS del juego.", v -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Activa primero las opciones de desarrollador en Ajustes.", Toast.LENGTH_LONG).show(); }
        });
        root.addView(gameCard, params(-1, -2));

        LinearLayout info = card();
        info.addView(text("Importante", 17, accent, true));
        TextView note = text("GameBoost no cambia voltajes, no desbloquea límites térmicos y no cierra procesos del sistema a la fuerza. Los cambios de rendimiento dependen del modelo, la temperatura y cada juego.", 14, Color.LTGRAY, false);
        LinearLayout.LayoutParams noteLp = params(-1, -2); noteLp.topMargin = dp(8);
        info.addView(note, noteLp);
        root.addView(info, params(-1, -2));
        setContentView(scroll);
    }

    private void addAction(LinearLayout parent, String title, String description, View.OnClickListener action) {
        LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(12), dp(12), dp(12), dp(12)); item.setBackgroundColor(Color.rgb(38, 44, 58));
        LinearLayout.LayoutParams itemLp = params(-1, -2); itemLp.topMargin = dp(10); item.setLayoutParams(itemLp);
        item.addView(text(title, 16, white, true));
        TextView desc = text(description, 13, Color.LTGRAY, false);
        LinearLayout.LayoutParams descLp = params(-1, -2); descLp.topMargin = dp(5); item.addView(desc, descLp);
        item.setOnClickListener(action); item.setClickable(true); parent.addView(item);
    }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Inicia Shizuku y activa su servicio primero.", Toast.LENGTH_LONG).show();
                updateShizukuStatus(); return;
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "GameBoost ya tiene permiso de Shizuku.", Toast.LENGTH_SHORT).show();
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_CODE);
            } else {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_CODE);
            }
            updateShizukuStatus();
        } catch (Throwable t) {
            Toast.makeText(this, "No se pudo consultar Shizuku. Comprueba que esté instalado y activo.", Toast.LENGTH_LONG).show();
        }
    }

    private void updateShizukuStatus() {
        if (shizukuStatus == null) return;
        try {
            if (!Shizuku.pingBinder()) shizukuStatus.setText("No conectado · abre Shizuku y activa el servicio.");
            else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) shizukuStatus.setText("Conectado · permiso concedido.");
            else shizukuStatus.setText("Servicio activo · falta conceder permiso a GameBoost.");
        } catch (Throwable t) { shizukuStatus.setText("No se pudo verificar el servicio."); }
    }

    @Override protected void onResume() { super.onResume(); updateShizukuStatus(); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { super.onActivityResult(requestCode, resultCode, data); updateShizukuStatus(); }
    private LinearLayout card() { LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(16), dp(16), dp(16)); c.setBackgroundColor(panel); LinearLayout.LayoutParams lp = params(-1, -2); lp.topMargin = dp(18); c.setLayoutParams(lp); return c; }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(bg); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent)); b.setTextSize(14); return b; }
    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
