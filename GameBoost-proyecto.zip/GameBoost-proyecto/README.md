# GameBoost - proyecto inicial Android

Proyecto Android nativo de ejemplo con pantalla principal y comprobación/solicitud de permiso de Shizuku.

## Compilación
Requiere Android SDK y Gradle 8.9+ con Java 17; Android Gradle Plugin 8.7.3.

En GitHub Actions se puede compilar con `gradle assembleDebug` desde la carpeta del proyecto.

## Estado
Esta es una base inicial, no un optimizador completo. No modifica CPU/GPU, temperatura, RAM del sistema ni límites térmicos. Las funciones adicionales deben implementarse y validarse por dispositivo.
