package com.gameboost.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView shizukuStatus;
    private static final int REQUEST_CODE = 2026;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,24,32));
        getWindow().setNavigationBarColor(Color.rgb(16,24,32));
        buildUi();
        updateShizukuStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        root.setBackgroundColor(Color.rgb(16,24,32));
        scroll.addView(root);

        TextView logo = text("GAMEBOOST", 28, Color.WHITE, true);
        root.addView(logo);
        TextView subtitle = text("Panel de juegos y herramientas", 14, 0xFFB8C4CE, false);
        root.addView(subtitle);
        spacer(22);

        addSection("ESTADO DEL SISTEMA", "GameBoost está instalado. Android limita las modificaciones de rendimiento que una app puede realizar sin permisos especiales.");
        addSection("SHIZUKU", "Conecta Shizuku para habilitar únicamente las operaciones compatibles y autorizadas.");
        shizukuStatus = text("Comprobando Shizuku…", 14, 0xFFFFD166, true);
        root.addView(shizukuStatus);
        Button connect = button("Comprobar / solicitar permiso Shizuku");
        connect.setOnClickListener(v -> requestShizuku());
        root.addView(connect);

        addSection("JUEGOS", "Puedes abrir un juego desde el lanzador de Android. La lista automática de juegos se añadirá en una siguiente versión.");
        Button games = button("Abrir lista de aplicaciones");
        games.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            try { startActivity(intent); } catch (Exception ignored) { }
        });
        root.addView(games);

        addSection("RENDIMIENTO", "Esta versión inicial no cambia CPU, GPU, temperatura ni límites térmicos. Evita promesas de FPS y cambios de sistema no compatibles.");
        addSection("AJUSTES", "Versión 1.0 · Proyecto inicial. Las funciones avanzadas requieren implementarse y probarse para tu dispositivo.");
        setContentView(scroll);
    }

    private void addSection(String title, String body) {
        spacer(16);
        TextView h = text(title, 16, 0xFF28C76F, true);
        root.addView(h);
        TextView b = text(body, 14, 0xFFE0E6EB, false);
        b.setPadding(0, dp(7), 0, dp(5));
        root.addView(b);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF28A866); bg.setCornerRadius(dp(12));
        b.setBackground(bg); b.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10); b.setLayoutParams(lp);
        return b;
    }

    private void spacer(int h) { View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }

    private void updateShizukuStatus() {
        if (shizukuStatus == null) return;
        if (!Shizuku.pingBinder()) {
            shizukuStatus.setText("Shizuku no está iniciado. Abre Shizuku y activa el servicio.");
            shizukuStatus.setTextColor(0xFFFFD166);
        } else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            shizukuStatus.setText("Shizuku conectado y permiso concedido.");
            shizukuStatus.setTextColor(0xFF28C76F);
        } else {
            shizukuStatus.setText("Shizuku está activo; falta conceder permiso a GameBoost.");
            shizukuStatus.setTextColor(0xFFFFD166);
        }
    }

    private void requestShizuku() {
        if (!Shizuku.pingBinder()) {
            shizukuStatus.setText("Abre Shizuku, inicia el servicio y vuelve a intentarlo.");
            return;
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            updateShizukuStatus();
        } else {
            Shizuku.addRequestPermissionResultListener((requestCode, grantResult) -> {
                if (requestCode == REQUEST_CODE) updateShizukuStatus();
            });
            Shizuku.requestPermission(REQUEST_CODE);
        }
    }
}
